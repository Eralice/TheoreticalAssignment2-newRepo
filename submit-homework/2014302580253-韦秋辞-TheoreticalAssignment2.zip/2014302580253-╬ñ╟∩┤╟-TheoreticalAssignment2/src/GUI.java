import java.awt.Color;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class GUI {
	public ATM atm;
	public JTextArea ta= new JTextArea();
	private JScrollPane sp = new JScrollPane(ta);
	private PrintStream output;
	public String input;	
	private boolean a;
	public GUI(){
	// ��¼����
		atm = new ATM();
		//��������	
			JFrame a=new JFrame("ATM");
			a.setBounds(600, 500, 600, 500);
			a.setBackground(Color.blue);
			a.setLayout(null);
		//���ּ�ȷ����ť
			JButton jb0=new JButton("0");
			JButton jb1=new JButton("1");
			JButton jb2=new JButton("2");
			JButton jb3=new JButton("3");
			JButton jb4=new JButton("4");
			JButton jb5=new JButton("5");
			JButton jb6=new JButton("6");
			JButton jb7=new JButton("7");
			JButton jb8=new JButton("8");
			JButton jb9=new JButton("9");
			JButton jbe=new JButton("Enter");
			a.add(jb0);
			a.add(jb1);
			a.add(jb2);
			a.add(jb3);
			a.add(jb4);
			a.add(jb5);
			a.add(jb6);
			a.add(jb7);
			a.add(jb8);
			a.add(jb9);
			a.add(jbe);
			jb1.setBounds(10,110,50,25);
			jb2.setBounds(80, 110, 50, 25);
			jb3.setBounds(150, 110, 50, 25);
			jb4.setBounds(10, 150, 50, 25);
			jb5.setBounds(80, 150, 50, 25);
			jb6.setBounds(150, 150, 50, 25);
			jb7.setBounds(10, 190, 50, 25);
			jb8.setBounds(80, 190, 50, 25);
			jb9.setBounds(150, 190, 50, 25);
			jb0.setBounds(10, 230, 50, 25);
			jbe.setBounds(80, 230, 120, 25);
		//�˻�����������				
			final TextArea ta=new TextArea(10,40);
			ta.setText("Welcome to the ATM!");		
			ta.setEditable(false);//�����ı��򲻿ɱ��༭
			a.add(ta);
			ta.setBounds(250,110,300,150);
			
		//����һ������
			a.add(sp);
			sp.setBounds(250, 110, 300, 150);
			sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			
			
		//�԰�ť���Ӽ����¼���ʵ�ֲ���
			//��ť1
			jb1.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"1");
					get_input("1");
				
				}
			});
			//��ť2
			jb2.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"2");
					get_input("2");
					
				}
			});
			//��ť3
			jb3.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"3");
					get_input("3");
					
				}
			});
			///��ť4
			jb4.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"4");
					get_input("4");
					
				}
			});
			//��ť5
			jb5.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"5");
					get_input("5");
					
				}
			});
			//��ť6
			jb6.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"6");
					get_input("6");
				
				}
			});
			//��ť7
			jb7.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"7");
					get_input("7");
					
				}
			});
			//��ť8
			jb8.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"8");
					get_input("8");
				
				}
			});
			//��ť9
			jb9.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"9");
					get_input("9");
					
				}
			});
			//��ť0
			jb0.addActionListener(new ActionListener() { 			
				public void actionPerformed(ActionEvent e) {
					ta.setText(ta.getText()+"0");
					get_input("0");
				
				}
			});
			//enter��ť
			jbe.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
				 //�ж��Ƿ�����ֵ					 
					if (input.length() > 0) {
						atm.keypad.num = Integer.parseInt(input);
					    atm.keypad.b = true;
					    input = "";
					}
				}
			});
			
			//����˵���Ϣ
			output = new PrintStream(System.out){
				public void println(String str) {
					ta.append(str + '\n');
				}
				public void print(String str) {
					ta.append(str);
				}
				public void println(double d) {
					ta.append(String.valueOf(d));
				}
			};
			System.setOut(output);
		    
							
			a.setVisible(true);
}
	//��ȡ����ֵ
	private void get_input(String i) {
		if (a==false) {
			input = i;
			a = true;
		}else {
			input = input + i;
		}
		//��JTextArea����ʾ����ֵ
		ta.append(i);
	}
}

