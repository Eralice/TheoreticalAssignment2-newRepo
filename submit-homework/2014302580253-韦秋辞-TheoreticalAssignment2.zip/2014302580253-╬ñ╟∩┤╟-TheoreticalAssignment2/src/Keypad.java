
public class Keypad
 {
	public int num;
	 public boolean b; // reads data from the command line
// no-argument constructor initializes the Scanner
 public Keypad()
 {
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {
	 b = false;
	 while (!b) {
		 System.out.print("");
	 }
	 return num;
 } // end method getInput
 }